package ex9_1;

public class Persona {
	String nom;
	String dni;
	int edat;
	String curs;
	String assignatura;
	
	public Persona() {
		
	}
	
	
	public Persona(String nom, String dni, int edat, String curs, String assignatura) {
		this.nom = nom;
		this.dni = dni;
		this.edat = edat;
		this.curs = curs;
		this.assignatura = assignatura;
		
		
	}
	public void esticaClase() {
		
	}


	public void mostrarDades() {
		// TODO Auto-generated method stub
		
	}
}
