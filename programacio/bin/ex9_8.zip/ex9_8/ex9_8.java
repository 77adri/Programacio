package ex9_8;

public class ex9_8 {

	public static void main(String[] args) {
		
	}

}
