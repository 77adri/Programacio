package ex9_8;

public class Cua {
    private Persona[] cua;
    private int capacitat;
    private int primera; 
    private int ultima;  
    private int nombreElements;

    public Cua(int capacitat) {
        this.capacitat = capacitat;
        cua = new Persona[capacitat];
        primera = 0;
        ultima = -1;
        nombreElements = 0;
    }

    public void afegirPersona(Persona persona) {
        if (nombreElements == capacitat) {
            System.out.println("La cua està plena, no es pot afegir més persones.");
            return;
        }
        ultima = (ultima + 1) % capacitat;
        cua[ultima] = persona;
        nombreElements++;
    }

    public Persona treurePersona() {
        if (nombreElements == 0) {
            System.out.println("La cua està buida, no es pot treure cap persona.");
            return null;
        }
        Persona personaTreure = cua[primera];
        primera = (primera + 1) % capacitat;
        nombreElements--;
        return personaTreure;
    }

    public void mostrarCua() {
        if (nombreElements == 0) {
            System.out.println("La cua està buida.");
            return;
        }
        System.out.println("Estat de la cua:");
        for (int i = 0; i < nombreElements; i++) {
            int index = (primera + i) % capacitat;
            System.out.println(cua[index]);
        }
    }

    public static void main(String[] args) {
        Cua cuaEspectacle = new Cua(5);
        cuaEspectacle.afegirPersona(new Persona("Maria", "12345678A"));
        cuaEspectacle.afegirPersona(new Persona("Joan", "87654321B"));
        cuaEspectacle.afegirPersona(new Persona("Laura", "56789012C"));

        cuaEspectacle.mostrarCua();

        cuaEspectacle.treurePersona();
        System.out.println("Persona eliminada de la cua.");

        cuaEspectacle.mostrarCua();
    }
}

